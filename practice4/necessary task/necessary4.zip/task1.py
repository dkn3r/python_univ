class Employee():
    def  __init__(self,name,salary,days):
        self.name = name
        self.salary = salary
        self.days = days
