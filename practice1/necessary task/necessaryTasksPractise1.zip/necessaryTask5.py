num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))
num3 = int(input("Enter the third number: "))

listOfNumbers = [num1,num2,num3]

print(f"Minimum number is: {min(listOfNumbers)}")
print(f"Maximum number is: {max(listOfNumbers)}")

