from tkinter import *
import random
import time
from Game import Game
from Coords import Coords
from Sprite import Sprite
from PlatformSprite import PlatformSprite
from DoorSprite import DoorSprite
from StickFigureSprite import StickFigureSprite
from CollisionCheck import CollisionCheck
