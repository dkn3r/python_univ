class Adress():
    def __init__(self, country, city, street, nbuild):
        self.country = country
        self.city = city
        self.street = street
        self.nbuild = nbuild
