word = list(input("Введіть слово: "))
lettetCount = {}
for letter in word:
    if letter in lettetCount:
        lettetCount[letter] += 1
    else:
        lettetCount[letter] = 1
most_common_letter = max(lettetCount, key=lambda k: lettetCount[k])
print("Буква, яка найчастіше зустрічається:", most_common_letter)
print("Кількість входжень цієї букви:", lettetCount[most_common_letter])