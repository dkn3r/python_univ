sentence = list(input("Введіть речення: "))
print("".join(sentence[::-1]))