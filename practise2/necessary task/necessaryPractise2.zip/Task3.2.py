n = int(input("Введіть n: "))
result = []
for i in range(1,n+1):
    result.append(i**2)
print(result)