age = int(input("Скільки Вам років? "))
if age < 18: print("Ви ще не повнолітній!")
else: print("Ви повнолітній!")